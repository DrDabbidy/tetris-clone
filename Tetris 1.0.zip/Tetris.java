/* Tetris remake
 * David De Martin
 * May 11, 2020
 */

import tetris.Game;
import javafx.application.Application;

public class Tetris 
{
    public static void main(String[] args) throws InterruptedException
    {
        Application.launch(Game.class, args);
    }
}
