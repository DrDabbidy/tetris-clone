package tetris;

import javafx.scene.paint.Color;

public class OBlock extends Block
{
    OBlock (int x, int y)
    {
        this.color = Color.web("#E6FF00");
        this.x = x;
        this.y = y;
        this.squares = new Square[][]{

            { new Square(0, 0, 25, this.color), new Square(1, 0, 25, this.color) },
            { new Square(0, 1, 25, this.color), new Square(1, 1, 25, this.color) },

        };
        this.boundingBoxLength = 2; // perhaps redundant from the 2S arr above
    }
}