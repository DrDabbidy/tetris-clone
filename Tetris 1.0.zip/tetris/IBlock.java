package tetris;

import javafx.scene.paint.Color;

public class IBlock extends Block
{
    IBlock (int x, int y)
    {
        this.color = Color.web("#0AB9E6");
        this.x = x;
        this.y = y;
        this.squares = new Square[][]{

            { null, new Square(1, 0, 25, this.color), null, null },
            { null, new Square(1, 1, 25, this.color), null, null },
            { null, new Square(1, 2, 25, this.color), null, null },
            { null, new Square(1, 3, 25, this.color), null, null }

        };
        this.boundingBoxLength = 4; // perhaps redundant from the 2S arr above
    } 
}