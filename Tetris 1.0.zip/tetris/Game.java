/* Main game class for Tetris. Learnt JavaFX from YouTuber "thenewboston" and packages from Gaet... ask him. Also, referenced 
 * websites are commented throughout. This was mostly to learn how to do specific things in javafx but never pertained directly to
 * Tetris or how to implement the game's logic. Further, I always customized the code and never copy-and-pasted any code into my project.
 * David De Martin
 * May 14, 2020
 */

package tetris;

import java.util.*;
import javafx.animation.AnimationTimer;
import javafx.application.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.shape.*;
import javafx.scene.text.Font;
import javafx.scene.effect.*; 
import javafx.scene.input.KeyEvent;
import javafx.event.EventHandler;

// Game class containing the Game methods
public class Game extends Application
{
    final int BOARD_WIDTH = 10;
    final int BOARD_HEIGHT = 24;

    // Rectangle[][] squares = new Rectangle[10][24]; // referenced https://stackoverflow.com/questions/35367060/gridpane-of-squares-in-javafx. Creates an array of rects
    GridPane boardUI = new GridPane(); // creates the grid that will store the rectangles for the UI
    //boolean[][] board = new boolean[10][24]; // creates the backend grid of bools which will tell WORKING ON THIS
    
    int framesSinceDrop = 0; // keeps track of how many frames it's been since the block has dropped one gridcell
    int dropRate = 48; // how many frames before the block drops. starts at 48 frames per drop
    boolean getBlock = true; // tells us if we need a new block.
    Block currentBlock; // current block we are manipulating and using
    int orderIndex = 0; // current index of the order we are at.
    int level = 0; // current level
    int linesThisLevel = 0;
    int[] dropRates = new int[]{ 48, 43, 38, 33, 28, 23, 18, 13, 8, 6, 5, 4, 3, 2, 1 }; // frame rates for each level
    int intScore = 0; // current score
    boolean gameOver = false; // tells if game is over
    int framesSinceLock = 0; // counts frames until the next block is spawned after one lock on the field
    boolean softDrop = false;

    // bools to tell if shift or rotation needs to occur
    boolean shiftR = false; 
    boolean shiftL = false;
    boolean rotateClockwise = false;
    boolean rotateCounterclockwise = false;
    

    // this is like the "main method" in javafx we override the start method in the application class to customize what we want it to do.
    @Override
    public void start(Stage primaryStage) throws Exception 
    {
        Stage gameWin = new Stage(); // create the game window
        gameWin.setTitle("Tetris by David"); // set the window title

        // create lighting effect for the blocks learnt on https://www.geeksforgeeks.org/javafx-light-point-class/
        // makes them look similar to the blocks in tetris or other retro games
        Light.Point light = new Light.Point(25.0/2, 25.0/2, 100.0, Color.GAINSBORO);
        Lighting lightEffect = new Lighting();
        lightEffect.setLight(light);

        // set the backgorund colour of the gridpane to be black by default
        BackgroundFill bgFill = new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY);
        Background background = new Background(bgFill);
        boardUI.setBackground(background);

        // // initiliaze the array of squares that will make up the 
        // for (int i = 0; i < squares.length; i++)
        // {
        //     for (int j = 0; j < squares[0].length; j++)
        //     {
        //         squares[i][j] = new Rectangle(25, 25, Color.BLACK);
        //     }
        // }

        // // add the sqaures to the gripane, which is basically a grid of objects to display
        // for (int i = 0; i < squares.length; i++)
        // {
        //     for (int j = 0; j < squares[0].length; j++)
        //     {
        //         boardUI.getChildren().add(squares[i][j]);
        //         boardUI.setConstraints(squares[i][j], i+1, j+1);
        //     }
        // }

        // create the grey border around the playfield by adding grey squares to the edges.
        for (int i = 0; i < BOARD_WIDTH + 2; i++)
        {
            for (int j = 0; j < BOARD_HEIGHT + 2; j++)
            {
                if (i == 0 || i == 11 || j == 0 || j == 25)
                {
                    Rectangle rect = new Rectangle(25, 25, Color.web("#6e6e6e")); // HEX code is from web
                    rect.setEffect(lightEffect); // this light effects gives the old retro block feel
                    boardUI.getChildren().add(rect);
                    boardUI.setConstraints(rect, i, j);
                }
            }
        }

        // add all the info labels on the right side of the screen for top score and score as well as the next piece
        Font tetrisFont = Font.loadFont(getClass().getResourceAsStream("\\tetrisFont.ttf"), 11); // create a font from the file tetrisFont.ttf as found on http://java-buddy.blogspot.com/2013/02/load-true-type-font-ttf-in-javafx.html

        Label topScoreTitle = new Label(" Top"); // create the label
        topScoreTitle.setFont(tetrisFont); // set the font
        topScoreTitle.setTextFill(Color.WHITE); // set the font colour

        Label topScore = new Label("999999999");
        topScore.setFont(tetrisFont);
        topScore.setTextFill(Color.WHITE);
        
        Label scoreTitle = new Label(" Score");
        scoreTitle.setFont(tetrisFont);
        scoreTitle.setTextFill(Color.WHITE);

        Label score = new Label("000000000");
        score.setFont(tetrisFont);
        score.setTextFill(Color.WHITE);

        Label next = new Label(" Next");
        next.setFont(tetrisFont);
        next.setTextFill(Color.WHITE);

        boardUI.getChildren().addAll(topScoreTitle, topScore, scoreTitle, score, next);
        boardUI.setConstraints(topScoreTitle, 12, 5);
        boardUI.setConstraints(topScore, 12, 6);
        boardUI.setConstraints(scoreTitle, 12, 8);
        boardUI.setConstraints(score, 12, 9);
        boardUI.setConstraints(next, 12, 11);

        // set the gap between squares to be 0
        boardUI.setHgap(0);
        boardUI.setVgap(0);

        // create the scene. this is what shows on the window. put the gripane into it so that the gripane shows
        Scene scene = new Scene(boardUI, 405, 658, Color.BLACK);

        scene.setOnKeyPressed(new EventHandler<KeyEvent>()
        {
            //@Override
            public void handle (KeyEvent event)
            {
                switch (event.getCode())
                {
                    case W:
                        // rotate the block counterclockwise
                        rotateCounterclockwise = true;
                        break;
                    case A:
                        // shift the block to the left
                        shiftL = true;
                        break;
                    case S:
                        // rotate the block clockwise
                        rotateClockwise = true;
                        break;
                    case D:
                        // shift the block right
                        shiftR = true;
                        break;
                    case SPACE:
                        // increase the drop rate when spacebar is held down
                        if (dropRate == dropRates[level])
                        {
                            dropRate = 3 - (level / 15); // formula for hard drop
                        }
                        softDrop = true;
                        break;
                }
            }
        });

        scene.setOnKeyReleased(new EventHandler<KeyEvent>()
        {
            //@Override
            public void handle (KeyEvent event)
            {
                switch (event.getCode())
                {
                    case SPACE:
                        // when spacebar released, return drop rate to regular speed
                        dropRate = dropRates[level];
                        softDrop = false;
                        break;
                }
            }
        });

        gameWin.setScene(scene);
        gameWin.show(); // show the window

        List<Integer> order = new ArrayList<Integer>(); // gives the order for the blocks to spawn
        for (int i = 0; i < 7; i++)
        {
            order.add(i);
        }
        Collections.shuffle(order); // shuffle the order of the spawning

        // use an AnimationTimer to do a certain action 60 times a second. This will give the game 60 fps. https://stackoverflow.com/questions/29962395/how-to-write-a-keylistener-for-javafx was referenced
        // in essence, this is where the game is: the game loop.
        AnimationTimer timer = new AnimationTimer()
        {
            @Override
            public void handle (long now)
            {
                // this code will be run every 60th of a second, allowing in theory for 60 fps.
                
                // runs if new block needs to be spawned
                if (getBlock)
                {
                    framesSinceLock++;
                    if (framesSinceLock >= 10)
                    {
                        framesSinceLock = 0;
                        getBlock = !getBlock;
                    
                        // if we're at the end of the list, we shuffle and return to the beginning
                        if (orderIndex == 7)
                        {
                            orderIndex = 0;
                            Collections.shuffle(order);
                        }

                        // generate the block given by the shuffled list at the index we are at: orderIndex
                        switch (order.get(orderIndex))
                        {
                            case 0:
                                currentBlock = new IBlock(3, 0);
                                break;
                            case 1:
                                currentBlock = new JBlock(3, 0);
                                break;
                            case 2:
                                currentBlock = new LBlock(3, 0);
                                break;
                            case 3:
                                currentBlock = new SBlock(3, 0);
                                break;
                            case 4:
                                currentBlock = new ZBlock(3, 0);
                                break;
                            case 5:
                                currentBlock = new TBlock(3, 0);
                                break;
                            case 6:
                                currentBlock = new OBlock(3, 0);
                                break;
                        }
                        orderIndex++; // increment order index for next time
                    
                        // check if we can spawn the block
                        if (!canSpawn(currentBlock, boardUI))
                        {
                            gameOver = true;
                        }

                        // spawn the block at the top of screen NEEDS CHECKER FOR END OF GAME!!!!!
                        for (int i = 0; i < currentBlock.squares.length; i++)
                        {
                            for (int j = 0; j < currentBlock.squares.length; j++)
                            {
                                if (currentBlock.squares[i][j] != null)
                                {
                                    boardUI.getChildren().add(currentBlock.squares[i][j].getSquare());
                                    boardUI.setConstraints(currentBlock.squares[i][j].getSquare(), j+1+currentBlock.getX(), i+1+currentBlock.getY());
                                }
                            }
                        }
                    }
                }
                else
                {
                    // shifts block left
                    if (shiftL)
                    {
                        // shiftL = false;
                        shiftLeft(currentBlock);
                    }

                    // shifts block right
                    if (shiftR)
                    {
                        // shiftR = false;
                        shiftRight(currentBlock);
                    }

                    // rotates block clockwise
                    if (rotateClockwise)
                    {
                        //rotateClockwise = false;
                        if (canRotateClockwise(currentBlock, boardUI))
                        {
                            currentBlock.rotateClockwise();
                            currentBlock.draw(boardUI);
                        }
                    }

                    //rotate block counterclockwise
                    if (rotateCounterclockwise)
                    {
                        //rotateCounterclockwise = false;
                        if (canRotateCounterclockwise(currentBlock, boardUI))
                        {
                            currentBlock.rotateCounterclockwise();
                            currentBlock.draw(boardUI);
                        }
                    }

                    // shift block down
                    if (framesSinceDrop++ >= dropRate)
                    {
                        framesSinceDrop = 0;
                        // code for making the block drop down one level...
                        // pseudo: for each square in block, if vertical coord+1 is occupied, check if any rows are filled. if so, clear the row. then, change the current block. Else, lower the block by one gridcell
                        boolean noCollision = shiftDown(currentBlock);
                        if (!noCollision)
                        {
                            getBlock = true;
                            if (checkForAndProcessLines(boardUI))
                            {
                                framesSinceLock -= 17;
                                setScore(intScore, score);
                                if (linesThisLevel >= 10)
                                {
                                    linesThisLevel -= 10;
                                    level++;
                                    dropRate = dropRates[level];
                                }
                            }
                        }
                        if (softDrop)
                        {
                            intScore += 1;
                            setScore(intScore, score);
                        }
                    }
                }

                if (gameOver)
                { 
                    // do game over stuff
                    System.out.println("game over");
                    
                    this.stop(); 
                }

                shiftL = false;
                shiftR = false;
                rotateClockwise = false;
                rotateCounterclockwise = false;
            }
        };

        timer.start(); // runs the timer
    }

    boolean shiftDown(Block block) // shift the block down. if not possible, return false. else, return true
    {
        // check if block can move down
        for (int i = 0; i < block.squares.length; i++)
        {
            for (int j = 0; j < block.squares.length; j++)
            {
                if (block.squares[i][j] != null)
                {
                    if (isContentNotInBlock(j+1+block.getX(), i+2+block.getY(), block))
                    {
                        return false; // we can't shift the block down. it will hit something.
                    }
                }
            }
        }

        block.setY(block.getY()+1); // shift the coords of the block down

        // shift the block on the gridpane
        block.draw(boardUI);

        return true;
    }

    boolean isContentNotInBlock(int x, int y, Block block) // checks if there are contents in the gridpane at given x and y in the playfield
    {
        for (Node n : boardUI.getChildren())
        {
            if (boardUI.getColumnIndex(n) == x && boardUI.getRowIndex(n) == y)
            {
                if (!contains(n, block) && n != null)
                {
                    return true;
                }
            }
        }
        return false;
    }

    boolean contains(Node n, Block block) // check if the node found in isContent method is part of the block. if it is, we don't count it for collision detection
    {
        for (int i = 0; i < block.squares.length; i++)
        {
            for (int j = 0; j < block.squares.length; j++)
            {
                if (block.squares[i][j] != null && n == block.squares[i][j].getSquare())
                {
                    return true;
                }
            }
        }
        return false;
    }

    boolean shiftLeft (Block block)
    {
        // check if block can move left
        for (int i = 0; i < block.squares.length; i++)
        {
            for (int j = 0; j < block.squares.length; j++)
            {
                if (block.squares[i][j] != null)
                {
                    if (isContentNotInBlock(j+block.getX(), i+1+block.getY(), block))
                    {
                        return false; // we can't shift the block left. it will hit something.
                    }
                }
            }
        }

        block.setX(block.getX()-1); // shift the coords of the block left

        // shift the block on the gridpane
        block.draw(boardUI);

        return true;
    }

    boolean shiftRight (Block block)
    {
        // check if block can move left
        for (int i = 0; i < block.squares.length; i++)
        {
            for (int j = 0; j < block.squares.length; j++)
            {
                if (block.squares[i][j] != null)
                {
                    if (isContentNotInBlock(j+2+block.getX(), i+1+block.getY(), block))
                    {
                        return false; // we can't shift the block left. it will hit something.
                    }
                }
            }
        }

        block.setX(block.getX()+1); // shift the coords of the block left

        // shift the block on the gridpane
        block.draw(boardUI);

        return true;
    }

    Node content (int x, int y, GridPane board) // get the Node at the given x and y in the gridpane
    {
        for (Node n : board.getChildren())
        {
            if (board.getColumnIndex(n) == x && board.getRowIndex(n) == y)
            {
                return n;
            }
        }
        return null;
    }

    boolean checkForAndProcessLines(GridPane board)
    {
        int numCompletedLines = 0; // will count number of completed lines
        List<Integer> completedLines = new ArrayList<Integer>(); // list of the indexes of those lines

        // look through the board. if a row is found with no null cells, add one to counter and add the index to the list
        for (int i = 0; i < BOARD_HEIGHT; i++)
        {
            boolean foundNullCell = false;
            for (int j = 0; j < BOARD_WIDTH; j++)
            {
                if (content(j+1, i+1, board) == null)
                {
                    foundNullCell = true;
                }
            }
            if (!foundNullCell)
            {
                numCompletedLines++;
                completedLines.add(i);
            }
        }

        // update the score
        switch (numCompletedLines)
        {
            case 1:
                linesThisLevel++;
                intScore += 40 * (level + 1);
                break;
            case 2:
                linesThisLevel += 2;
                intScore += 100 * (level + 1);
                break;
            case 3:
                linesThisLevel += 3;
                intScore += 300 * (level + 1);
                break;
            case 4:
                linesThisLevel += 4;
                intScore += 1200 * (level + 1);
                break;
        }

        if (completedLines.size() > 0)
        {
            // remove the lines from the board
            for (int i = 0; i < completedLines.size(); i++)
            {
                // removes the squares from the rows that are filled and shift the lines above down
                removeLine(completedLines.get(i), board);
                shiftLinesAboveDown(completedLines.get(i), board);
            }
            return true; // needed to know if we need to update the score
        }
        return false;
    }

    void shiftLinesAboveDown (int row, GridPane board)
    {
        for (int i = row-1; i >= 0; i--)
        {
            for (int j = 0; j < BOARD_WIDTH; j++)
            {
                Node n = content(j+1, i+1, board);
                if (n != null)
                {
                    board.setConstraints(n, j+1, i+2);
                }
            }
        }
    }

    void removeLine (int row, GridPane board)
    {
        for (int j = 0; j < BOARD_WIDTH; j++)
        {
            board.getChildren().remove(content(j+1, row+1, board));
        }
    }

    // resets the score label based on a new score
    void setScore (int score, Label label)
    {
        String stringScore = Integer.toString(score); // change the score to a string to display as text
        int l = stringScore.length(); // store the length because it will be changing as we add chars

        if (l < 9) 
        {
            for (int i = 0; i < 9 - l; i++) // add 0s to pad the left of the score label for that RETRO FEEL
            {
                stringScore = "0" + stringScore;
            }
        }
        label.setText(stringScore);
    }

    // check if the block can rotate clockwise BUGGED
    boolean canRotateClockwise(Block block, GridPane board)
    {
        for (int i = 0; i < block.boundingBoxLength; i++)
        {
            for (int j = 0; j < block.boundingBoxLength; j++)
            {
                if (block.squares[i][j] != null)
                {
                    if (isContentNotInBlock(block.boundingBoxLength-i+block.getX(), j+1+block.getY(), block))
                    {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    // check if the block can rotate counterclockwise BUGGED
    boolean canRotateCounterclockwise(Block block, GridPane board)
    {
        for (int i = 0; i < block.boundingBoxLength; i++)
        {
            for (int j = 0; j < block.boundingBoxLength; j++)
            {
                if (block.squares[i][j] != null)
                {
                    if (isContentNotInBlock(i+1+block.getX(), block.boundingBoxLength-j+block.getY(), block))
                    {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    //check if there is room to spawn a block. if not, we will end the game
    boolean canSpawn(Block block, GridPane board)
    {
        for (int i = 0; i < currentBlock.squares.length; i++)
        {
            for (int j = 0; j < currentBlock.squares.length; j++)
            {
                if (currentBlock.squares[i][j] != null)
                {
                    if (content(j+1+block.getX(), i+1+block.getY(), board) != null) // if there is something in that space
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }
}
