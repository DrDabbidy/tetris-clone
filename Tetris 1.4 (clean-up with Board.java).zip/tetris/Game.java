/* Main game class for Tetris. Learnt JavaFX from YouTuber "thenewboston" and packages from Gaet... ask him. Also, referenced 
 * websites are commented throughout. This was mostly to learn how to do specific things in javafx but never pertained directly to
 * Tetris or how to implement the game's logic. Further, I always customized the code and never copy-and-pasted any code into my project.
 * David De Martin
 * May 14, 2020
 */

package tetris;

import java.util.*;
import javafx.animation.AnimationTimer;
import javafx.application.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.shape.*;
import javafx.scene.text.Font;
import javafx.scene.effect.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.event.EventHandler;

// Game class containing the Game methods
public class Game extends Application
{
    Board board = new Board();
    Block currentBlock; // current block we are manipulating and using
    
    boolean gameOver = false; // tells if game is over
    boolean getBlock = true; // tells us if we need a new block.
    boolean softDrop = false; // tells if the block is soft dropping
    
    int level = 14; // current level
    int linesThisLevel = 0;
    int intScore = 0; // current score
    
    int[] dropRates = new int[]{ 48, 43, 38, 33, 28, 23, 18, 13, 8, 6, 5, 4, 3, 2, 1 }; // frame rates for each level
    int dropRate = dropRates[level]; // how many frames before the block drops. starts at 48 frames per drop
    int framesSinceDrop = 0; // keeps track of how many frames it's been since the block has dropped one gridcell
    int framesSinceLock = 0; // counts frames until the next block is spawned after one lock on the field
    
    Icons icons = new Icons(); // icons for the "next" functionality
    List<Integer> order = getOrder(); // create a block order
    int orderIndex = 0; // current index of the order we are at.

    // bools to tell if shift or rotation needs to occur
    boolean shiftR = false; 
    boolean shiftL = false;
    boolean rotateClockwise = false;
    boolean rotateCounterclockwise = false;
    

    // this is like the "main method" in javafx we override the start method in the application class to customize what we want it to do.
    @Override
    public void start(Stage primaryStage) throws Exception 
    {
        Stage gameWindow = new Stage(); // create the game window
        gameWindow.setTitle("Tetris by David"); // set the window title

        // create the scene. this is what shows on the window. put the gripane into it so that the gripane shows
        Scene scene = new Scene(board.getBoard(), 420, 658, Color.BLACK);

        scene.setOnKeyPressed(new EventHandler<KeyEvent>()
        {
            @Override
            public void handle (KeyEvent event)
            {
                switch (event.getCode())
                {
                    case W:
                        // rotate the block counterclockwise
                        rotateCounterclockwise = true;
                        break;
                    case A:
                        // shift the block to the left
                        shiftL = true;
                        break;
                    case S:
                        // rotate the block clockwise
                        rotateClockwise = true;
                        break;
                    case D:
                        // shift the block right
                        shiftR = true;
                        break;
                    case SPACE:
                        // increase the drop rate when spacebar is held down
                        if (dropRate == dropRates[level])
                        {
                            dropRate = 3 - (level / 15); // formula for hard drop
                        }
                        softDrop = true;
                        break;
                }
            }
        });

        scene.setOnKeyReleased(new EventHandler<KeyEvent>()
        {
            //@Override
            public void handle (KeyEvent event)
            {
                switch (event.getCode())
                {
                    case SPACE:
                        // when spacebar released, return drop rate to regular speed
                        dropRate = dropRates[level];
                        softDrop = false;
                        break;
                }
            }
        });

        gameWindow.setScene(scene);
        gameWindow.show(); // show the window

        // use an AnimationTimer to do a certain action 60 times a second. This will give the game 60 fps. https://stackoverflow.com/questions/29962395/how-to-write-a-keylistener-for-javafx was referenced
        // in essence, this is where the game is: the game loop.
        AnimationTimer timer = new AnimationTimer()
        {
            @Override
            public void handle (long now)
            {
                // this code will be run every 60th of a second, allowing in theory for 60 fps.
                
                // runs if new block needs to be spawned
                if (getBlock)
                {
                    //framesSinceLock++;
                    if (++framesSinceLock >= 10)
                    {
                        framesSinceLock = 0;
                        getBlock = !getBlock;

                        // generate the block given by the shuffled list at the index we are at: orderIndex
                        currentBlock = getNewBlock(order, orderIndex++); // increment order index for next time
                        
                        // if we're at the end of the list, we shuffle and return to the beginning
                        if (orderIndex == 7)
                        {
                            orderIndex = 0;
                            Collections.shuffle(order);
                        }

                        // set the next block icon to show the upcoming block
                        board.setNext(order, orderIndex, icons);

                        // check if we can spawn the block
                        if (!board.canSpawnBlock(currentBlock))
                        {
                            gameOver = true;
                        }
                        
                        board.spawnBlock(currentBlock);
                    }
                }
                else
                {
                    // shifts block left
                    if (shiftL && board.canShiftBlock(currentBlock, -1, 0))
                    {
                        board.shiftBlock(currentBlock, -1, 0);
                    }

                    // shifts block right
                    if (shiftR && board.canShiftBlock(currentBlock, 1, 0))
                    {
                        board.shiftBlock(currentBlock, 1, 0);
                    }

                    // rotates block clockwise
                    if (rotateClockwise && board.canRotateBlockClockwise(currentBlock))
                    {
                        currentBlock.rotateClockwise();
                        board.drawBlock(currentBlock);
                    }

                    //rotate block counterclockwise
                    if (rotateCounterclockwise && board.canRotateBlockCounterclockwise(currentBlock))
                    {
                        currentBlock.rotateCounterclockwise();
                        board.drawBlock(currentBlock);
                    }

                    // shift block down
                    if (++framesSinceDrop >= dropRate)
                    {
                        framesSinceDrop = 0;
                        // code for making the block drop down one level...
                        // pseudo: for each square in block, if vertical coord+1 is occupied, check if any rows are filled. if so, clear the row. then, change the current block. Else, lower the block by one gridcell
                        if (board.canShiftBlock(currentBlock, 0, 1))
                        {
                            board.shiftBlock(currentBlock, 0, 1);
                        }
                        else
                        {
                            getBlock = true;
                            int[] linesAndScore = board.checkForAndProcessLines(level); // { numCompletedLines, score }
                            if (linesAndScore[0] > 0)
                            {
                                intScore += linesAndScore[1];
                                linesThisLevel += linesAndScore[0];

                                framesSinceLock -= 17;

                                setScore(intScore, board.getScore());

                                if (linesThisLevel >= 10)
                                {
                                    linesThisLevel -= 10;
                                    level++;
                                    dropRate = dropRates[level];
                                }
                            }
                        }
                        if (softDrop)
                        {
                            intScore += 1;
                        }
                    }
                }

                if (gameOver)
                { 
                    this.stop(); // basically same as "break;" for the game loop 
                }


                shiftL = false;
                shiftR = false;
                rotateClockwise = false;
                rotateCounterclockwise = false;
            }
        };

        timer.start(); // runs the timer
    }

    Block getNewBlock (List<Integer> order, int orderIndex) // returns a new block based on the order
    {
        switch (order.get(orderIndex))
        {
            case 0:
                return new IBlock(3, -1);
            case 1:
                return new JBlock(3, 0);
            case 2:
                return new LBlock(3, 0);
            case 3:
                return new SBlock(3, 0);
            case 4:
                return new ZBlock(3, 0);
            case 5:
                return new TBlock(3, 0);
            case 6:
                return new OBlock(3, 0);
        }
        return null;
    }

    List<Integer> getOrder () 
    {
        List<Integer> order = new ArrayList<Integer>(); // gives the order for the blocks to spawn
        for (int i = 0; i < 7; i++)
        {
            order.add(i);
        }
        Collections.shuffle(order); // shuffle the order of the spawning
        return order;
    }

    // resets the score label based on a new score
    void setScore (int score, Label label)
    {
        String stringScore = Integer.toString(score); // change the score to a string to display as text
        int l = stringScore.length(); // store the length because it will be changing as we add chars

        if (l < 9) 
        {
            for (int i = 0; i < 9 - l; i++) // add 0s to pad the left of the score label for that RETRO FEEL
            {
                stringScore = "0" + stringScore;
            }
        }
        label.setText(stringScore);
    }
}
