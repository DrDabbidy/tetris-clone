package tetris;

import java.util.*;
import javafx.animation.AnimationTimer;
import javafx.application.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.shape.*;
import javafx.scene.text.Font;
import javafx.scene.effect.*; 
import javafx.scene.input.KeyEvent;
import javafx.event.EventHandler;

// contains the effects that are used for the GUI
public class Effects 
{
    // create lighting effect for the blocks learnt on https://www.geeksforgeeks.org/javafx-light-point-class/
    // makes them look similar to the blocks in tetris or other retro games
    static Light.Point light = new Light.Point(25.0/2, 25.0/2, 100.0, Color.GAINSBORO);    // creates a light which shines from a point
    public static Lighting lightEffect = new Lighting(light);                              // creates new lighting (javafx thingy)

    static BackgroundFill bgFill = new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY);    // makes a new black bg fill
    public static Background background = new Background(bgFill);                                       // makes a bg with the bg fill above    
}