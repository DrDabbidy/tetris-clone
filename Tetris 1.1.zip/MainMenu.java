import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.scene.text.Font;

public class MainMenu 
{
    Font tetrisFont = Font.loadFont(getClass().getResourceAsStream("\\tetrisFont.ttf"), 11); // create a font from the file tetrisFont.ttf
    Button start = new Button("Start");
    Button settings = new Button("Settings");
    Button howToPlayBack = new Button("Back");
    Button howToPlay = new Button("Info");

    Scene mainMenu;
    Scene settingsMenu;
    Scene howToPlayMenu;

    BorderPane border = new BorderPane();
    VBox buttons = new VBox();

    MainMenu ()
    {
        start.setFont(tetrisFont);
        settings.setFont(tetrisFont);
        howToPlayBack.setFont(tetrisFont);
        howToPlay.setFont(tetrisFont);

        buttons.getChildren().addAll(start, howToPlay, settings);
        border.setCenter(buttons);
    }

}