package tetris;

import java.util.*;
import javafx.animation.AnimationTimer;
import javafx.application.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.shape.*;
import javafx.scene.text.Font;
import javafx.scene.effect.*; 
import javafx.scene.input.KeyEvent;
import javafx.event.EventHandler;

public class Board 
{

    GridPane board = new GridPane();
    final int BOARD_WIDTH = 10;
    final int BOARD_HEIGHT = 24;

    Board()
    {
        // set the backgorund colour of the gridpane to be black by default
        board.setBackground(Effects.background);
        
        // add the grey border
        addBorder();

        // add info labels like score, top, etc.
        addLabels();

        // set the gap between squares to be 0
        board.setHgap(0);
        board.setVgap(0);
    }

    void addBorder ()
    {
        // create the grey border around the playfield by adding grey squares to the edges.
        for (int i = 0; i < BOARD_WIDTH + 2; i++)
        {
            for (int j = 0; j < BOARD_HEIGHT + 2; j++)
            {
                if (i == 0 || i == 11 || j == 0 || j == 25)
                {
                    Rectangle rect = new Rectangle(25, 25, Color.web("#6e6e6e")); // HEX code is from web
                    rect.setEffect(Effects.lightEffect); // this light effects gives the old retro block feel
                    board.getChildren().add(rect);
                    board.setConstraints(rect, i, j);
                }
            }
        }
    }

    void addLabels ()
    {
        // add all the info labels on the right side of the screen for top score and score as well as the next piece
        Font tetrisFont = Font.loadFont(getClass().getResourceAsStream("\\tetrisFont.ttf"), 11); // create a font from the file tetrisFont.ttf as found on http://java-buddy.blogspot.com/2013/02/load-true-type-font-ttf-in-javafx.html
        // above font's licence
        /* 
            The FontStruction “Tetris” (https://fontstruct.com/fontstructions/show/1102867) by Patrick Lauke
            is licensed under a Creative Commons Attribution license (http://creativecommons.org/licenses/by/3.0/).
        */

        Label topScoreTitle = new Label(" Top"); // create the label
        topScoreTitle.setFont(tetrisFont); // set the font
        topScoreTitle.setTextFill(Color.WHITE); // set the font colour

        Label topScore = new Label("999999999");
        topScore.setFont(tetrisFont);
        topScore.setTextFill(Color.WHITE);
        
        Label scoreTitle = new Label(" Score");
        scoreTitle.setFont(tetrisFont);
        scoreTitle.setTextFill(Color.WHITE);

        Label score = new Label("000000000");
        score.setFont(tetrisFont);
        score.setTextFill(Color.WHITE);

        Label next = new Label(" Next");
        next.setFont(tetrisFont);
        next.setTextFill(Color.WHITE);

        Rectangle filler = new Rectangle(15, 15, Color.BLACK); // random filler for formatting

        board.getChildren().addAll(topScoreTitle, topScore, scoreTitle, score, next, filler);
        board.setConstraints(topScoreTitle, 13, 5);
        board.setConstraints(topScore, 13, 6);
        board.setConstraints(scoreTitle, 13, 8);
        board.setConstraints(score, 13, 9);
        board.setConstraints(next, 13, 11);
        board.setConstraints(filler, 12, 12);
    }

    boolean isContentNotInBlock (int x, int y, Block block) // checks if there are contents in the gridpane at given x and y in the playfield
    {
        for (Node n : this.board.getChildren())
        {
            if (this.board.getColumnIndex(n) == x && this.board.getRowIndex(n) == y)
            {
                if (!blockContainsNode(n, block) && n != null) // if the found node is not in the block and not null, then it will be hit if we shift
                {
                    return true;
                }
            }
        }
        return false;
    }

    boolean blockContainsNode (Node n, Block block) // check if the node found in isContent method is part of the block. if it is, we don't count it for collision detection
    {
        for (int i = 0; i < block.squares.length; i++)
        {
            for (int j = 0; j < block.squares.length; j++)
            {
                if (block.squares[i][j] != null && n == block.squares[i][j].getSquare())
                {
                    return true;
                }
            }
        }
        return false;
    }

    Node getContent (int x, int y) // get the Node at the given x and y in the gridpane
    {
        for (Node n : board.getChildren())
        {
            if (this.board.getColumnIndex(n) == x && this.board.getRowIndex(n) == y)
            {
                return n;
            }
        }
        return null;
    }

    int[] checkForAndProcessLines (int level)
    {
        int score = 0;
        int numCompletedLines = 0; // will count number of completed lines
        List<Integer> completedLines = new ArrayList<Integer>(); // list of the indexes of those lines

        // look through the board. if a row is found with no null cells, add one to counter and add the index to the list
        for (int i = 0; i < BOARD_HEIGHT; i++)
        {
            boolean foundNullCell = false;
            for (int j = 0; j < BOARD_WIDTH; j++)
            {
                if (getContent(j+1, i+1) == null)
                {
                    foundNullCell = true;
                }
            }
            if (!foundNullCell)
            {
                numCompletedLines++;
                completedLines.add(i);
            }
        }

        // update the score
        switch (numCompletedLines)
        {
            case 1:
                score += 40 * (level + 1);
                break;
            case 2:
                score += 100 * (level + 1);
                break;
            case 3:
                score += 300 * (level + 1);
                break;
            case 4:
                score += 1200 * (level + 1);
                break;
        }

        if (completedLines.size() > 0)
        {
            // remove the lines from the board
            for (int i = 0; i < completedLines.size(); i++)
            {
                // removes the squares from the rows that are filled and shift the lines above down
                removeLine(completedLines.get(i));
                shiftLinesAboveDown(completedLines.get(i));
            } 
        }

        return new int[]{ numCompletedLines, score }; // return needed info
    }

    void removeLine (int row)
    {
        for (int j = 0; j < BOARD_WIDTH; j++)
        {
            this.board.getChildren().remove(getContent(j+1, row+1));
        }
    }

    void shiftLinesAboveDown (int row)
    {
        for (int i = row-1; i >= 0; i--)
        {
            for (int j = 0; j < BOARD_WIDTH; j++)
            {
                Node n = getContent(j+1, i+1);
                if (n != null)
                {
                    this.board.setConstraints(n, j+1, i+2);
                }
            }
        }
    }

    // check if the block can rotate clockwise BUGGED
    boolean canRotateBlockClockwise (Block block)
    {
        for (int i = 0; i < block.boundingBoxLength; i++)
        {
            for (int j = 0; j < block.boundingBoxLength; j++)
            {
                if (block.squares[i][j] != null)
                {
                    if (isContentNotInBlock(block.boundingBoxLength-i+block.getX(), j+1+block.getY(), block))
                    {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    boolean canRotateBlockCounterclockwise (Block block)
    {
        for (int i = 0; i < block.boundingBoxLength; i++)
        {
            for (int j = 0; j < block.boundingBoxLength; j++)
            {
                if (block.squares[i][j] != null)
                {
                    if (isContentNotInBlock(i+1+block.getX(), block.boundingBoxLength-j+block.getY(), block))
                    {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    //check if there is room to spawn a block. if not, we will end the game
    boolean canSpawnBlock (Block block)
    {
        for (int i = 0; i < block.squares.length; i++)
        {
            for (int j = 0; j < block.squares.length; j++)
            {
                if (block.squares[i][j] != null)
                {
                    if (getContent(j+1+block.getX(), i+1+block.getY()) != null) // if there is something in that space
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    // spawns the block onto the board
    void spawnBlock (Block block)
    {
        for (int i = 0; i < block.squares.length; i++)
        {
            for (int j = 0; j < block.squares.length; j++)
            {
                if (block.squares[i][j] != null)
                {
                    this.board.getChildren().add(block.squares[i][j].getSquare());
                    this.board.setConstraints(block.squares[i][j].getSquare(), j+1+block.getX(), i+1+block.getY());
                }
            }
        }
    }

    public void drawBlock (Block block)
    {
        for (int i = 0; i < block.squares.length; i++) // go through the x and y coords of the block
        {
            for (int j = 0; j < block.squares.length; j++)
            {
                if (block.squares[i][j] != null)
                {
                    // reset the position of the squares that make up the block
                    this.board.setConstraints(block.squares[i][j].getSquare(), j+1+block.getX(), i+1+block.getY());
                }
            }
        }
    }

    // made a method that takes care of all of these... will try... makes it cleaner
    // boolean shiftBlockLeft (Block block)
    // {
    //     // check if block can move left
    //     for (int i = 0; i < block.squares.length; i++)
    //     {
    //         for (int j = 0; j < block.squares.length; j++)
    //         {
    //             if (block.squares[i][j] != null)
    //             {
    //                 if (isContentNotInBlock(j+block.getX(), i+1+block.getY(), block))
    //                 {
    //                     return false; // we can't shift the block left. it will hit something.
    //                 }
    //             }
    //         }
    //     }

    //     block.setX(block.getX()-1); // shift the coords of the block left

    //     // shift the block on the gridpane
    //     block.draw(this.board);

    //     return true;
    // }

    // boolean shiftRight (Block block)
    // {
    //     // check if block can move left
    //     for (int i = 0; i < block.squares.length; i++)
    //     {
    //         for (int j = 0; j < block.squares.length; j++)
    //         {
    //             if (block.squares[i][j] != null)
    //             {
    //                 if (isContentNotInBlock(j+2+block.getX(), i+1+block.getY(), block))
    //                 {
    //                     return false; // we can't shift the block left. it will hit something.
    //                 }
    //             }
    //         }
    //     }

    //     block.setX(block.getX()+1); // shift the coords of the block left

    //     // shift the block on the gridpane
    //     block.draw(board);

    //     return true;
    // }

    // boolean shiftDown (Block block) // shift the block down. if not possible, return false. else, return true
    // {
    //     // check if block can move down
    //     for (int i = 0; i < block.squares.length; i++)
    //     {
    //         for (int j = 0; j < block.squares.length; j++)
    //         {
    //             if (block.squares[i][j] != null)
    //             {
    //                 if (isContentNotInBlock(j+1+block.getX(), i+2+block.getY(), block))
    //                 {
    //                     return false; // we can't shift the block down. it will hit something.
    //                 }
    //             }
    //         }
    //     }

    //     block.setY(block.getY()+1); // shift the coords of the block down

    //     // shift the block on the gridpane
    //     block.draw(board);

    //     return true;
    // }

    void shiftBlock (Block block, int xChange, int yChange) // shift the block down. if not possible, return false. else, return true
    {
        // shift the coords of the block according to x and y change
        block.setX(block.getX()+xChange);
        block.setY(block.getY()+yChange); 

        // shift the block on the gridpane
        drawBlock(block);
    }

    boolean canShiftBlock (Block block, int xChange, int yChange)
    {
        // check if block can't shift
        for (int i = 0; i < block.squares.length; i++)
        {
            for (int j = 0; j < block.squares.length; j++)
            {
                if (block.squares[i][j] != null)
                {
                    if (isContentNotInBlock(j+1+xChange+block.getX(), i+1+yChange+block.getY(), block))
                    {
                        return false; // we can't shift the block down. it will hit something.
                    }
                }
            }
        }

        return true;
    }
}